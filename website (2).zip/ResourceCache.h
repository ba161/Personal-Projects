#pragma once
#include <iostream>
#include <fstream>
#include <map>
#include <filesystem>

enum class ResourceType {
    HTML,
    JAVASCRIPT,
    CSS,
    PNG,
    JPG,
    TEXT,
    ICON,
    NONE
};

class Resource {
public:
    ResourceType type;
    std::string content;
};

class ResourceCache {
public:
    const std::string* mainPage;

    std::map<std::string, Resource> res;

    void loadDirectory(const std::filesystem::directory_entry & dentry)
    {

        for (const auto& entry : std::filesystem::directory_iterator(dentry))
        {
            if (std::filesystem::is_regular_file(entry)) 
            {
                const std::string filePath = entry.path().string();
                const std::string fileExtension = entry.path().extension().string();

                ResourceType type = getResourceType(fileExtension);
                if (type != ResourceType::NONE) 
                {
                    std::ifstream file(filePath,std::ios::binary);
                    if (file) {
                        std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
                        res["/"+entry.path().filename().string()] = {type, content};
                        file.close();
                    }
                }
            }
            else if (std::filesystem::is_directory(entry))
            {
                loadDirectory(entry);
            }
        }
    }
    void load(const std::string& path) 
    {
        std::filesystem::path directoryPath(path);

        if (!std::filesystem::is_directory(directoryPath)) {
            std::cout << "Error: Invalid directory path." << std::endl;
            return;
        }
        loadDirectory(std::filesystem::directory_entry(directoryPath));
    }
    
private:
    ResourceType getResourceType(const std::string& extension) {
        if (extension == ".html") {
            return ResourceType::HTML;
        }
        else if (extension == ".js") {
            return ResourceType::JAVASCRIPT;
        }
        else if (extension == ".txt") {
            return ResourceType::TEXT;
        }
        else if (extension == ".css") {
            return ResourceType::CSS;
        }
        else if (extension == ".png") {
            return ResourceType::PNG;
        }
        else if (extension == ".jpg") {
            return ResourceType::JPG;
        }
        else if (extension == ".ico") {
            return ResourceType::ICON;
        }
        else {
            return ResourceType::NONE; // Default to HTML type for unknown extensions
        }
    }
};

extern ResourceCache* resourceCache;
