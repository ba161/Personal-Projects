#pragma once

#include "ResourceHandler.h"
#include "ResourceCache.h"


bool h1(http::request<http::string_body>& req)
{
	std::string url = req.target();
	if(url == "/")
	{
		url = *(resourceHandler->mainPage);
	}
	auto it = resourceCache->res.find(url);

	if(it != resourceCache->res.end())
	{
		req.body() = it->second.content;
		return true;
	}
	return false;

}



bool h2(http::request<http::string_body>& req)
{

	auto it = resourceCache->res.find("/DC.html");

	if (it != resourceCache->res.end())
	{
		req.body() = it->second.content;
		return true;
	}
	return false;

}

void initUrl()
{
	resourceHandler->addGetHandler("/*", h1);
	resourceHandler->addGetHandler("/DC/*", h2);

}