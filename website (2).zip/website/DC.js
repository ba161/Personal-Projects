dc_data = null
dc_data2 = null
mc_id = null
dc_lowestRank = 99999999999;
dc_lowestCat = 0;
var urlParams = new URLSearchParams(window.location.search);
var params = {};


params["ID"] = window.location.href.split('/').pop().split('.')[0];

MCmain = document.getElementsByClassName("DC1")[0];

date1 = new Date();
date2 = new Date();

mc_FC = [];
mc_ManyC = true;
mc_C = [-1];
mc_P = [-1];
mc_D = [-1];
mc_T = [-1];
mc_S = 0;
mc_filterChanged = true;
function dcLoadData()
{
    request = new XMLHttpRequest();
    request.open('GET', '/data1.txt', false); // The third parameter sets the request to be synchronous
    request.send();
    if (request.status === 200) 
    {
        dc_data = JSON.parse(request.responseText);
    } 
    else
    {
        console.error('Error:', request.status);
    }

    request = new XMLHttpRequest();
    request.open('GET', '/tool'+params["ID"] +".txt", false); // The third parameter sets the request to be synchronous
    request.send();
    if (request.status === 200) 
    {
        dc_data2 = JSON.parse(request.responseText);
    } 
    else
    {
        console.error('Error:', request.status);
    }
    
}
function dcProcessData()
{


    for(let i = 0 ; i < dc_data.Tools.length; i++)
    {
        dc_data.Tools[i].ID =i;
        dc_data.Tools[i].DR = new Date(dc_data.Tools[i].R);
    }

}
function dcGetRank()
{


    cArray = [];
    for(var i = 0 ; i < dc_data.Tools[params["ID"]].C.length; i++)
    {
        cArray.push([]);

        for(var j = 0; j < dc_data.Tools.length; j++)
        {
            for(k = 0 ; k < dc_data.Tools[j].C.length; k++)
            {
                if(dc_data.Tools[params["ID"]].C[i] == dc_data.Tools[j].C[k])
                {
                    cArray[i].push(dc_data.Tools[j]);
                }
            }
        }
    }

    for(var i = 0; i < cArray.length ; i++)
    {
        currentRank = cArray[i].length;

        for(var j = 0; j <cArray[i].length; j++)
        {
            if(cArray[i][j].V > dc_data.Tools[params["ID"]].V )
            {
                currentRank--;
            }
        }
        if(currentRank <= dc_lowestRank)
        {
            dc_lowestRank = currentRank;
            dc_lowestCat = dc_data.Tools[params["ID"]].C[i];
        }
    }

}
function dcDisplayStatic(comp)
{
    var text = '        <div class="DC2 S1">' +
	'            <div class="DC3">' +
	'                <div class="DC9"> <a  href="'+dc_data.Tools[params["ID"]].L+'" class="DC24"><img class="DC5" src="'+dc_data2.I+'"></a></div>' +
	'                <div class="DC4"> ' +
	'                    <div class="DC6">' +
	'                        <div class="DC7">'+dc_data.Tools[params["ID"]].N+'</div>' +
	'                        <div class="DC8">edit</div>' +
	'                    </div>' +
	'                    <div class="DC10"> ' +
	'                        <div class="DC11">' +
	'                            <div class="DC12">rank:</div>' +
	'                            <div class="DC15">#'+dc_lowestRank+'</div>' +
	'                            <div class="DC15">#'+dc_data.Category[dc_lowestCat].split(' ').map(function (word) {return word.charAt(0).toUpperCase() + word.slice(1);}).join('')
    +'</div>' +
	'                        </div>' +
	'                        <div class="DC11">' +
	'                            <div class="DC12">votes:</div>' +
	'                            <div class="DC14">'+dc_data.Tools[params["ID"]].V+'</div>' +
	'                        </div>' +
	'                        <div class="DC11">' +
	'                            <div class="DC12">visits:</div>' +
	'                            <div class="DC14">'+dc_data.Tools[params["ID"]].V1+'</div>' +
	'                        </div>' +
	'                        <div class="DC11">' +
	'                            <div class="DC12">rating:</div>' +
	'                            <div class="DC14">'+dc_data.Tools[params["ID"]].S+'/5</div>' +
	'                        </div>' +
	'                    </div>' +
	'                    <div class="DC16">';
    for(var j = 0; j < dc_data.Tools[params["ID"]].C.length; j++)
    {
        text +='<div class="DC15">#'+dc_data.Category[dc_data.Tools[params["ID"]].C[j]].split(' ').map(function (word) {return word.charAt(0).toUpperCase() + word.slice(1);}).join('')+'</div>';

    }
    for(var j = 0; j < dc_data.Tools[params["ID"]].P.length; j++)
    {
        text +='<div class="DC15">#'+dc_data.Price[dc_data.Tools[params["ID"]].P[j]].split(' ').map(function (word) {return word.charAt(0).toUpperCase() + word.slice(1);}).join('')+'</div>';
    }
    text += '<div class="DC15">#'+dc_data.Difficulty[dc_data.Tools[params["ID"]].H].split(' ').map(function (word) {return word.charAt(0).toUpperCase() + word.slice(1);}).join('')+'</div>';
    for(var j = 0; j < dc_data.Tools[params["ID"]].T.length; j++)
    {
        text +='<div class="DC15">#'+dc_data.Type[dc_data.Tools[params["ID"]].T[j]].split(' ').map(function (word) {return word.charAt(0).toUpperCase() + word.slice(1);}).join('')+'</div>';
    }
    text+= '                    </div>' +
	'                    <div class="DC17">' +
	'                        <a href="'+dc_data.Tools[params["ID"]].L+'" class="DC13" >visit</a>' +
	'                        <a href="http://www.google.com" class="DC13" >vote</a>' +
	'                        <a href="http://www.google.com" class="DC13" >rate</a>' +
	'                    </div>' +
	'                    ' +
	'                </div>' +
	'            </div>' +
	'            <div class="DC18">';

                 text += 	'                <div class="DC22">'+
        '                    <div class="DC19">Description</div>'+
        '<div class="DC21">'+dc_data.Tools[params["ID"]].D+'</div>' +
        '</div>';
    for (var i = 0; i< dc_data2.F.length; i++)
    {
        if(dc_data2.F[i][0] == "0")
        {
             text += 	'                <div class="DC22">'+
        '                    <div class="DC19">'+dc_data2.F[i][1]+'</div>'+
        '<div class="DC21">'+dc_data2.F[i][2]+'</div>' +
        '</div>';
        }
        else if(dc_data2.F[i][0] == "1")
        {
             text += 	'                <div class="DC22">'+
        '                    <div class="DC19">'+dc_data2.F[i][1]+'</div>';
                for(var j = 0; j < dc_data2.F[i][2].length ; j++)
        {
            text+='<div class="DC21">- '+dc_data2.F[i][2][j]+'</div>';
        }
        text += '</div>';
        }
       

    }
	text +='                <div class="DC17">' +
	'                    <a href="'+dc_data.Tools[params["ID"]].L+'" class="DC13 DC23" >visit</a>' +
	'                </div>' +
	'            </div>' +
	'        </div>';
    comp.innerHTML = text;
}


function dcExecute()
{
    dcDisplayStatic(MCmain);
}
function dcSetupStatic()
{

}

dcLoadData();
dcProcessData();
dcGetRank();
dcExecute();
document.addEventListener('DOMContentLoaded', function() 
{

    dcSetupStatic(MCmain);
})

function performAfterDOMUpdate() {
}
