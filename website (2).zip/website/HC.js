function hcDisplayComponent(comp)
{
    comp.innerHTML = '<nav class="HC1 S1"><div class="HC2"><a href="/MC.html"><img src="/3.png" class="HC3"></a></div><div class="HC4"><a href="/MC.html" class="HC5">home</a><a href="/SC.html" class="HC5">submit tool</a></div><div></div></nav>'
    
}
HCmain = document.getElementsByClassName("HC");

function hcdisplay()
{
    for (var i = 0; i < HCmain.length; i++)
    {
        hcDisplayComponent(HCmain[i]);
    }

}
hcdisplay()