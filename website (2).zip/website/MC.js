mc_data = null
mc_id = null
MCmain = document.getElementsByClassName("MC1")[0];

date1 = new Date();
date2 = new Date();

mc_FC = [];
mc_ManyC = true;
mc_C = [-1];
mc_P = [-1];
mc_D = [-1];
mc_T = [-1];
mc_S = 0;
mc_filterChanged = true;
function hcLoadData()
{
    request = new XMLHttpRequest();
    request.open('GET', 'data1.txt', false); // The third parameter sets the request to be synchronous
    request.send();
    if (request.status === 200) 
        {
            mc_data = JSON.parse(request.responseText);
        } 
    else
        {
          console.error('Error:', request.status);
        }
   
}
function hcProcessData()
{


    for(let i = 0 ; i < mc_data.Tools.length; i++)
    {
        mc_data.Tools[i].ID =i;
        mc_data.Tools[i].DR = new Date(mc_data.Tools[i].R);
    }

}
function hcDisplayStatic(comp)
{
    mc_id = 5
    var text = '        <div class="MC2 S1">' +
	'            <div class="MC15">' +
	'                <h1 class="MC16">AI Tools Top List</h1>' +
	'            </div>' +
	'            <div class="MC3">' +
	'                <label for="MCID0" class="S2">AI tools search bar</label>' +
	'                <input type="search" id="MCID0" class="MC13" placeholder="search">' +    
	'                <label for="MCID1" class="S2">filter by category</label>' +
	'                <select id="MCID1" class="MC13" >' +
	'                    <option value="-1">-- Category --</option>' ;
    var ii = 0;
    for(var i = 0; i <mc_data.Category.length; i++)
    {
        text += '<option value="'+ii+'">'+mc_data.Category[i]+'</option>'
        ii++;
    }
	text +='                </select>' +
	'                <label for="MCID2" class="S2">filter by pricing</label>' +
	'                <select id="MCID2" class="MC13" >' +
	'                    <option value="-1">-- pricing--</option>';
    ii = 0;
    for(var i = 0; i <mc_data.Price.length; i++)
    {
        text += '<option value="'+ii+'">'+mc_data.Price[i]+'</option>'
        ii++;

    }
	text +='                </select>' +
	'                <label for="MCID3" class="S2">filter by difficulty</label>' +
	'                <select id="MCID3" class="MC13">' +
	'                    <option value="-1">-- Difficulty --</option>';

    ii = 0;
    for(var i = 0; i <mc_data.Difficulty.length; i++)
    {
        text += '<option value="'+ii+'">'+mc_data.Difficulty[i]+'</option>';
        ii++;

    }
    text +='                </select>' +
	'                <label for="MCID4" class="S2">filter by Type</label>' +
	'                <select id="MCID4" class="MC13">' +
	'                    <option value="-1">-- Type --</option>';

    ii = 0;
    for(var i = 0; i <mc_data.Type.length; i++)
    {
        text += '<option value="'+ii+'">'+mc_data.Type[i]+'</option>'
        ii++;

    }

	text +='                </select>' +
	'                <label for="MCID5" class="S2">sort</label>' +
	'                <select id="MCID5" class="MC13">' +
	'                    <option value="-1">-- Sort --</option>' +
	'                    <option value="0">Most Votes</option>' +
    '                    <option value="1">Least Votes</option>' +
	'                    <option value="2">Most Popular</option>' +
    '                    <option value="3">Least Popular</option>' +
    '                    <option value="4">Newest</option>' +
    '                    <option value="5">Oldest</option>' +
	'                    <option value="6">A-Z</option>' +
    '                    <option value="7">Z-A</option>' +
	'                </select>' +
	'                <button type="button" class="MC14">advance filter</button>' +
	'            </div>' +
	'            <div class="MC17">'+
    '                <div class="MC23">' +
    '                    <div class="MC22">Category</div>' +
    '                    <div class="MC18">';
    text +='<div class="MC21"><input id="MCID'+mc_id+'"  type="checkbox"><label class="MC24" for="MCID'+mc_id+'">All</label> </div>';
    mc_id++;
    for(var i = 0; i < mc_data.Category.length; i++)
    {
        text +='<div class="MC21"><input id= "MCID'+mc_id+'"  type="checkbox"><label class="MC24" for="MCID'+mc_id+'">'+mc_data.Category[i]+'</label> </div>';
        mc_id++;
    }
    text+='                    </div>' +
    '                </div>' +
	'                <div class="MC23">' +
	'                    <div class="MC22">Pricing model</div>' +
	'                    <div class="MC18">';
    text +='<div class="MC21"><input id="MCID'+mc_id+'"  type="checkbox"><label class="MC24" for="MCID'+mc_id+'">All</label> </div>';
    mc_id++;
    for(var i = 0; i < mc_data.Price.length; i++)
    {
        text +='<div class="MC21"><input id= "MCID'+mc_id+'"  type="checkbox"><label class="MC24" for="MCID'+mc_id+'">'+mc_data.Price[i]+'</label> </div>';
        mc_id++;
    }
	text+='                    </div>' +
	'                </div>' +
	'                <div class="MC23">' +
	'                    <div class="MC22">Difficulty</div>' +
	'                    <div class="MC18">';
    text +='<div class="MC21"><input id="MCID'+mc_id+'"  type="checkbox"><label class="MC24" for="MCID'+mc_id+'">All</label> </div>';
    mc_id++;
    for(var i = 0; i < mc_data.Difficulty.length; i++)
    {
        text +='<div class="MC21"><input id= "MCID'+mc_id+'"  type="checkbox"><label class="MC24" for="MCID'+mc_id+'">'+mc_data.Difficulty[i]+'</label> </div>';
        mc_id++;
    }
	text +='                    </div>' +
	'                </div>' +
	'                <div class="MC23">' +
	'                    <div class="MC22">Type</div>' +
	'                    <div class="MC18">' ;
    text +='<div class="MC21"><input id="MCID'+mc_id+'"  type="checkbox"><label class="MC24" for="MCID'+mc_id+'">All</label> </div>';
    for(var i = 0; i < mc_data.Type.length; i++)
    {
        text +='<div class="MC21"><input id= "MCID'+mc_id+'"  type="checkbox"><label class="MC24" for="MCID'+mc_id+'">'+mc_data.Type[i]+'</label> </div>';
        mc_id++;
    }
	
	text+='                    </div>' +
	'                </div>' +
	'                <div class="MC23">' +
	'                    <div class="MC22">Sort</div>' +
	'                    <div class="MC18">';
	text+='                        <div class="MC21"><input id= "MCID'+mc_id+'" name="MCN1"  type="radio"><label class="MC24" for="MCID'+mc_id+'">Most Votes</label> </div>' +
	'                        <div class="MC21"><input id= "MCID'+(mc_id+1)+'" name="MCN1"  type="radio"><label class="MC24" for="MCID'+(mc_id+1)+'">Least Votes</label> </div>' +
	'                        <div class="MC21"><input id= "MCID'+(mc_id+2)+'" name="MCN1"  type="radio"><label class="MC24" for="MCID'+(mc_id+2)+'">Most Popular</label> </div>' +
	'                        <div class="MC21"><input id= "MCID'+(mc_id+3)+'" name="MCN1"  type="radio"><label class="MC24" for="MCID'+(mc_id+3)+'">Least Popular</label> </div>' +
	'                        <div class="MC21"><input id= "MCID'+(mc_id+4)+'" name="MCN1"  type="radio"><label class="MC24" for="MCID'+(mc_id+4)+'">Newest</label> </div>' +
	'                        <div class="MC21"><input id= "MCID'+(mc_id+5)+'" name="MCN1"  type="radio"><label class="MC24" for="MCID'+(mc_id+5)+'">Oldest</label> </div>' +
    '                        <div class="MC21"><input id= "MCID'+(mc_id+6)+'" name="MCN1"  type="radio"><label class="MC24" for="MCID'+(mc_id+6)+'">A-Z</label> </div>' +
	'                        <div class="MC21"><input id= "MCID'+(mc_id+7)+'" name="MCN1"  type="radio"><label class="MC24" for="MCID'+(mc_id+7)+'">Z-A</label> </div>' ;
    mc_id+= 8;
	text+= '                    </div>' +
	'                </div>' +
	'                <div>' +
	'                    <div>' +
	'                        <button class="MC33">clear</button>' +
	'                        <button class="MC34">close</button>' +
	'                    </div>' +
	'                </div>' +
	'            </div>' +
	'            <div class="MC4">'+           
	'            </div>' +
	'            <div class="MC25"> ' +
	'            </div>' +
	'        </div>';
    
    comp.innerHTML = text;
}
function hcFilterData(data)
{
    if(mc_ManyC)
    {
        mc_FC = [];
        mc_FC.elem = [];
        for(var i = 0; i < mc_data.Category.length; i++)
        {
            mc_FC.push({"N" : mc_data.Category[i] , "elem": []});
        }
        for(var i = 0; i < mc_data.Tools.length; i++)
        {
            if(!mc_data.Tools[i].D.toUpperCase().includes(data.querySelector("#MCID0").value.toUpperCase()) && !mc_data.Tools[i].N.toUpperCase().includes(data.querySelector("#MCID0").value.toUpperCase()))
            {
                continue;

            }
            add = false;
            for(var j = 0; j < mc_D.length; j++)
            {
                if(mc_D[j] == -1)
                {
                    add = true;
                    break;
                } 
            }
            if(!add)
            {
                for(var k = 0; k < mc_D.length; k++)
                {

                    if(mc_data.Tools[i].H == mc_D[k])
                    {
                        add = true;
                        k = mc_D.length;
                    }
                    
                }
               
                if(add == false)
                {
                    continue;
                }
            }

            add = false;
            for(var j = 0; j < mc_P.length; j++)
            {
                if(mc_P[j] == -1)
                {
                    add = true;
                    break;
                } 
            }
            if(!add)
            {
                for(var k = 0; k < mc_P.length; k++)
                {
                    for(var j = 0; j < mc_data.Tools[i].P.length; j++)
                    {
                        if(mc_data.Tools[i].P[j] == mc_P[k])
                        {
                            add = true;
                            j= mc_data.Tools[i].P[j].length;
                            k = mc_P.length;
                        }
                    }
                }
                if(add == false)
                {
                    continue;
                }
            }
            add = false;
            for(var j = 0; j < mc_T.length; j++)
            {
                if(mc_T[j] == -1)
                {
                    add = true;
                    break;
                } 
            }
            if(!add)
            {
                for(var k = 0; k < mc_T.length; k++)
                {
                    for(var j = 0; j < mc_data.Tools[i].T.length; j++)
                    {
                        if(mc_data.Tools[i].T[j] == mc_T[k])
                        {
                            add = true;
                            j= mc_data.Tools[i].T[j].length;
                            k = mc_T.length;
                        }
                    }
                }
                if(add == false)
                {
                    continue;
                }
            }
            for(var i2 = 0; i2 < mc_data.Tools[i].C.length; i2++)
            {
                mc_FC[mc_data.Tools[i].C[i2]].elem.push(mc_data.Tools[i]);
            }

        }
        for(var i = 0; i < mc_FC.length; i++)
        {
            if(mc_S == -1 || mc_S == 0)
            {
                mc_FC[i].elem.sort(function(a, b)
                 {
                    return b.V - a.V;
                 });
            }
            else if (mc_S == 1)
            {
                mc_FC[i].elem.sort(function(a, b)
                 {
                    return a.V - b.V;
                 });
    
            }
            else if (mc_S == 2)
            {
                mc_FC[i].elem.sort(function(a, b)
                 {
                    return b.V1 - a.V1;
                  });
            }
            else if (mc_S == 3)
            {
                mc_FC[i].elem.sort(function(a, b)
                 {
                    return a.V1 - b.V1;
                  });
            }
            else if (mc_S == 4)
            {
                mc_FC[i].elem.sort(function(a, b) {
                    return b.DR - a.DR;
                  });
            }
            else if (mc_S == 5)
            {
                mc_FC[i].elem.sort(function(a, b) {
                    return a.DR - b.DR;
                  });
            }
            else if (mc_S == 6)
            {
                mc_FC[i].elem.sort(function(a, b) {
                    var nameA = a.N.toUpperCase(); 
                    var nameB = b.N.toUpperCase();
                    if (nameA < nameB) {
                      return -1; 
                    }
                    if (nameA > nameB) {
                      return 1; 
                    }
                    return 0;
                  });
            }
            else if (mc_S == 7)
            {
                mc_FC[i].elem.sort(function(a, b) {
                    var nameA = a.N.toUpperCase(); 
                    var nameB = b.N.toUpperCase();
                    if (nameA > nameB) {
                      return -1; 
                    }
                    if (nameA < nameB) {
                      return 1; 
                    }
                    return 0;
                  });
            }
        }

    }
    else
    {
        mc_FC = [];
        add = false;
        for(var i = 0; i < mc_data.Tools.length; i++)
        {
            if(!mc_data.Tools[i].D.toUpperCase().includes(data.querySelector("#MCID0").value.toUpperCase()) && !mc_data.Tools[i].N.toUpperCase().includes(data.querySelector("#MCID0").value.toUpperCase()))
            {
                continue;

            }
            for(var j = 0 ; j < mc_data.Tools[i].C.length ; j++)
            {
                
                if(mc_data.Category[mc_data.Tools[i].C[j]].toUpperCase().includes(data.querySelector("#MCID0").value.toUpperCase()))
                {
                    add = true;
                    j = mc_data.Tools[i].C.length
                }
            }
            if(add == false)
            {
                continue;
            }
            add = false;
            for(var j = 0; j < mc_data.Tools[i].C.length; j++)
            {
                if(mc_data.Tools[i].C[j] == mc_C)
                {
                    add = true;
                    j = mc_data.Tools[i].C.length;
                } 
            }
            if(add == false)
            {
                continue
            }
            add = false;
            for(var k = 0; k < mc_D.length; k++)
            {
                if(mc_D[k] == -1 || mc_data.Tools[i].H == mc_D[k])
                {
                    add = true;
                    break;
                } 
            }            
            if(add == false)
            {
                continue
            }
            add = false;
            for(var k = 0; k < mc_P.length; k++)
            {
                if(mc_P[k] == -1)
                {
                    add = true;
                    break;
                } 
                for(var j = 0; j < mc_data.Tools[i].P.length; j++)
                {
                    if(mc_data.Tools[i].P[j] == mc_P[k])
                    {
                        add = true;
                        j= mc_data.Tools[i].P[j].length;
                        k = mc_P.length;
                    }
                }
            } 
            if(add == false)
            {
                continue
            }
            add = false;
            for(var k = 0; k < mc_T.length; k++)
            {
                if(mc_T[k] == -1)
                {
                    add = true;
                    break;
                } 
                for(var j = 0; j < mc_data.Tools[i].T.length; j++)
                {
                    if(mc_data.Tools[i].T[j] == mc_T[k])
                    {
                        add = true;
                        j= mc_data.Tools[i].T[j].length;
                        k = mc_T.length;
                    }
                }
            } 
            if(add == false)
            {
                continue
            }
            mc_FC.push(mc_data.Tools[i]);
        }
        if(mc_S == -1 || mc_S == 0)
        {
            mc_FC.sort(function(a, b)
             {
                return a.V - b.V;
             });
        }
        else if (mc_S == 1)
        {
            mc_FC.sort(function(a, b)
             {
                return b.V - a.V;
             });

        }
        else if (mc_S == 2)
        {
            mc_FC.sort(function(a, b)
             {
                return a.V1 - b.V1;
              });
        }
        else if (mc_S == 3)
        {
            mc_FC.sort(function(a, b)
             {
                return b.V1 - a.V1;
              });
        }
        else if (mc_S == 4)
        {
            mc_FC.sort(function(a, b) {
                return a.DR - b.DR;
              });
        }
        else if (mc_S == 5)
        {
            mc_FC.sort(function(a, b) {
                return b.DR - a.DR;
              });
        }
        else if (mc_S == 6)
        {
            mc_FC.sort(function(a, b) {
                var nameA = a.N.toUpperCase(); 
                var nameB = b.N.toUpperCase();
                if (nameA < nameB) {
                  return -1; 
                }
                if (nameA > nameB) {
                  return 1; 
                }
                return 0;
              });
        }
        else if (mc_S == 7)
        {
            mc_FC.sort(function(a, b) {
                var nameA = a.N.toUpperCase(); 
                var nameB = b.N.toUpperCase();
                if (nameA > nameB) {
                  return -1; 
                }
                if (nameA < nameB) {
                  return 1; 
                }
                return 0;
              });
        }
       

    }


 
}
function hcDisplayFiltered(data)
{
    text = ""
    if(mc_ManyC == true)
    {
        counter = 0;
        for( var i = 0; i < mc_FC.length; i++)
        {
            if(mc_FC[i].elem.length > 0)
            {
                counter++;
                text += '<div class="MC5">' +
                '                    <div class="MC6">' +
                '                        <div class="MC9">'+mc_FC[i].N+'</div>' +
                '                    </div>' +
                '                    <ol class="MC7">';
                for (var j = 0; j < mc_FC[i].elem.length; j++)
                {
                    text +='<li class="MC8" >'+j+'. &nbsp&nbsp&nbsp <img src="'+mc_FC[i].elem[j].I+'" class="MC10"> <a class="MC11" href="/DC/'+mc_FC[i].elem[j].ID+'.html">'+mc_FC[i].elem[j].N+'</a>  </li>';
        
                }
        
                text +='                    </ol>' +
                '                    <div class="MC12"></div>' +
                '                </div>';
            }
            
    
        }
        data.querySelector(".MC4").innerHTML = text;

        obj = data.querySelector(".MC4");
        width = obj.offsetWidth;
        n = 1;
        if(width >= 1380)
        {
            n = 4;
        }
        else if(width >= 1180)
        {
            n = 3
        }
        else if(width >= 748)
        {
            n = 2
        }

        n = (n-counter% n)%n;
        for(var i = 0; i < n ; i++)
        {
            text += '<div class="MC5" style="visibility: hidden;"></div>';
        }

        obj.innerHTML = text;
    }
    else
    {
        for (var i = 0; i < mc_FC.length; i++)
        {
        text += '                <button class="MC26">'+
        '<a href="'+mc_FC[i].L+'" class="MC27">' +
        '                        <div class="MC29">' +
        '                            <img class="MC28" src="'+mc_FC[i].I+'"></img>' +
        '                            <div>'+mc_FC[i].N+' ('+mc_FC[i].V+')</div>' +
        '                        </div>' +
        '                    </a>' +
        '                    <div class="MC30">'+mc_FC[i].D+'</div>' +
        '                    <div class="MC31">';
        for(var j = 0; j < mc_FC[i].C.length; j++)
        {
            text += '<div class="MC32">#'+mc_data.Category[mc_FC[i].C[j]].split(' ').map(function (word) {return word.charAt(0).toUpperCase() + word.slice(1);}).join('')+'</div>';

        }
        for(var j = 0; j < mc_FC[i].P.length; j++)
        {
        text += '<div class="MC32">#'+mc_data.Price[mc_FC[i].P[j]].split(' ').map(function (word) {return word.charAt(0).toUpperCase() + word.slice(1);}).join('')+'</div>';

        }
        text += '<div class="MC32">#'+mc_data.Difficulty[mc_FC[i].H].split(' ').map(function (word) {return word.charAt(0).toUpperCase() + word.slice(1);}).join('')+'</div>';
        for(var j = 0; j < mc_FC[i].T.length; j++)
        {
            text += '<div class="MC32">#'+mc_data.Type[mc_FC[i].T[j]].split(' ').map(function (word) {return word.charAt(0).toUpperCase() + word.slice(1);}).join('')+'</div>';

        }
        text+=    '                    </div>' +
            '                </button>';

        }
        obj = data.querySelector(".MC25");
        width = obj.offsetWidth;
        n = 1;
        if(width >= 1380)
        {
            n = 4;
        }
        else if(width >= 1180)
        {
            n = 3
        }
        else if(width >= 748)
        {
            n = 2
        }

        n = (n-mc_FC.length% n)%n;
        for(var i = 0; i < n ; i++)
        {
            text += '<button class="MC26" style="visibility: hidden;"></button>';
        }

        obj.innerHTML = text;

    }

  



}
function hcSetupFiltered(data)
{


}
function hcExecute()
{
    hcDisplayStatic(MCmain);


}
function hcSetupStatic()
{
    var selectElement = MCmain.querySelector('#MCID1');
    selectElement.addEventListener('change', function(event) {
        mc_C = [event.target.value];
        mc_ManyC = false;
        mc_filterChanged = true;
        MCmain.querySelector('.MC25').style.display = 'flex';
        MCmain.querySelector('.MC4').style.display = 'none';
        for(var i=0; i< mc_C.length; i++)
        {
            if(mc_C[i] == -1)
            {
                mc_ManyC = true;
                MCmain.querySelector('.MC25').style.display = 'none';
                MCmain.querySelector('.MC4').style.display = 'flex';
                break;
            }
        }
        });
    selectElement = MCmain.querySelector('#MCID2');
    selectElement.addEventListener('change', function(event) {
        mc_P = [event.target.value];
        mc_filterChanged = true;
        });
    selectElement = MCmain.querySelector('#MCID3');
    selectElement.addEventListener('change', function(event) {
        mc_D = [event.target.value];
        mc_filterChanged = true;
        });
    selectElement = MCmain.querySelector('#MCID4');
    selectElement.addEventListener('change', function(event) {
    mc_T = [event.target.value];
    mc_filterChanged = true;
        });
    selectElement = MCmain.querySelector('#MCID5');
    selectElement.addEventListener('change', function(event) {
    mc_S = event.target.value;
    mc_filterChanged = true;
        });
    selectElement = MCmain.querySelector('.MC14');
    selectElement.addEventListener('click', function(event) {
        MCmain.querySelector('.MC17').style.display = 'flex';
        MCmain.querySelector('.MC3').style.display = 'none';
        mc_filterChanged = true;

        });
    selectElement = MCmain.querySelector('.MC34');
    selectElement.addEventListener('click', function(event) {
            MCmain.querySelector('.MC17').style.display = 'none';
            MCmain.querySelector('.MC3').style.display = 'flex';
            mc_filterChanged = true;
            });

    selectElement = MCmain.querySelector('#MCID0');
    selectElement.addEventListener('input', function(event) {
    mc_filterChanged = true;
    });
}

hcLoadData();
hcProcessData();
hcExecute();
document.addEventListener('DOMContentLoaded', function() 
{

    hcSetupStatic(MCmain);
    hcDisplayFiltered(MCmain);    


})

function performAfterDOMUpdate() {
}

function animate() {

 

  if (mc_filterChanged) {
    hcFilterData(MCmain);
    hcDisplayFiltered(MCmain);
    mc_filterChanged = false;
  }
  requestAnimationFrame(animate);
}

// Start the animation loop
requestAnimationFrame(animate);
window.addEventListener('resize', () =>{    mc_filterChanged = true;
});
